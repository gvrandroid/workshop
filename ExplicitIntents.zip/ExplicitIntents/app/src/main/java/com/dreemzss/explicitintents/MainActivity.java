package com.dreemzss.explicitintents;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
EditText un,pwd;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        un = findViewById(R.id.user_edit);
        pwd = findViewById(R.id.pwd_edit);

    }

    public void goToSignUp(View view) {
        Intent in =new Intent(this,SignUp.class);
        startActivity(in);
    }

    public void startWelcome(View view) {
        if (un.getText().toString().isEmpty() || pwd.getText().toString().isEmpty())
        {
            Toast.makeText(this,"Enter Valid Details",Toast.LENGTH_LONG).show();
        }
        else
        {
            if (un.getText().toString().equals(pwd.getText().toString()) )
            {
                Intent in = new Intent(this,Welcome.class);
                startActivity(in);
            }
            else
            {
                Toast.makeText(this,"Invalid User.!",Toast.LENGTH_LONG).show();
            }
        }

    }
}
