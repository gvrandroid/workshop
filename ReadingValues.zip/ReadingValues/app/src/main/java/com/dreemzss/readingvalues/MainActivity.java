package com.dreemzss.readingvalues;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    TextView myInput;
    EditText name_edit;
    String myData;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

         name_edit = findViewById(R.id.name_edit);
         myInput = findViewById(R.id.myInput);

    }

    public void submitData(View view) {
        myData = name_edit.getText().toString();
        myInput.setText(myData);
    }
}
