package in.saimedha.optionsmenu;

import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    LinearLayout ll;
    TextView title;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
         ll = findViewById(R.id.linear);
         title = findViewById(R.id.heading);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.options_menu,menu);
        return super.onCreateOptionsMenu(menu);

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId())
        {
            case R.id.red:
                ll.setBackgroundColor(Color.RED);
                break;
            case R.id.green:
                ll.setBackgroundResource(R.drawable.ic_launcher_background);
                break;
            case R.id.blue:
                title.setTextColor(Color.BLUE);
                break;
            case R.id.yellow:
                ll.setBackgroundColor(Color.YELLOW);
                break;
        }
        return super.onOptionsItemSelected(item);
    }
}
