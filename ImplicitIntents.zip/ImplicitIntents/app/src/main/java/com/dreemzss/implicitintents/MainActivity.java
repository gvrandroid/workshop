package com.dreemzss.implicitintents;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {
Intent in;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void makeCall(View view) {
         in = new Intent();
        in.setAction(Intent.ACTION_CALL);
        in.setData(Uri.parse("tel:9985416787"));
        startActivity(in);
    }

    public void dialPhone(View view) {
         in = new Intent(Intent.ACTION_DIAL);
        in.setData(Uri.parse("tel:9985416787"));
        startActivity(in);
    }

    public void browseWebsite(View view) {
         in = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/"));
        startActivity(in);
    }
}
