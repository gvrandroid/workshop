package in.nitw.videoview;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.MediaController;
import android.widget.VideoView;

public class MainActivity extends AppCompatActivity {
VideoView vv;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        vv = findViewById(R.id.vv);
    }

    public void playVideo(View view) {
        vv.setVideoPath("/sdcard/inkem.mp4");
        vv.setMediaController(new MediaController(this));
        vv.start();
    }
}
